'use client'

import { useEffect, useState, useRef } from 'react'

/* ═══════════════════════════════════════════
   Scroll Observer
   ═══════════════════════════════════════════ */
function useScrollObserver() {
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add('visible')
            observer.unobserve(e.target)
          }
        })
      },
      { threshold: 0.1, rootMargin: '0px 0px -30px 0px' }
    )
    document.querySelectorAll('[data-animate]').forEach((el) => observer.observe(el))
    return () => observer.disconnect()
  }, [])
}

/* ═══════════════════════════════════════════
   Count Up
   ═══════════════════════════════════════════ */
function useCountUp(target: number, suffix: string, dur = 2000) {
  const [val, setVal] = useState('0' + suffix)
  const ref = useRef<HTMLDivElement>(null)
  const ran = useRef(false)

  useEffect(() => {
    const el = ref.current
    if (!el) return
    const obs = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting && !ran.current) {
          ran.current = true
          const t0 = performance.now()
          const tick = (now: number) => {
            const p = Math.min((now - t0) / dur, 1)
            const ease = 1 - Math.pow(1 - p, 3)
            setVal(Math.round(ease * target) + suffix)
            if (p < 1) requestAnimationFrame(tick)
          }
          requestAnimationFrame(tick)
        }
      },
      { threshold: 0.5 }
    )
    obs.observe(el)
    return () => obs.disconnect()
  }, [target, suffix, dur])

  return { ref, val }
}

/* ═══════════════════════════════════════════
   Icons (Lucide-style SVGs)
   ═══════════════════════════════════════════ */
const I = {
  tax: (
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" /><polyline points="14 2 14 8 20 8" /><line x1="9" y1="15" x2="15" y2="15" /><line x1="9" y1="11" x2="15" y2="11" />
    </svg>
  ),
  book: (
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <rect x="2" y="3" width="20" height="18" rx="2" /><line x1="2" y1="9" x2="22" y2="9" /><line x1="10" y1="3" x2="10" y2="9" />
      <circle cx="7" cy="14" r="0.5" fill="currentColor" /><circle cx="13" cy="14" r="0.5" fill="currentColor" /><circle cx="7" cy="18" r="0.5" fill="currentColor" /><circle cx="13" cy="18" r="0.5" fill="currentColor" /><circle cx="19" cy="14" r="0.5" fill="currentColor" />
    </svg>
  ),
  users: (
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M23 21v-2a4 4 0 0 0-3-3.87" /><path d="M16 3.13a4 4 0 0 1 0 7.75" />
    </svg>
  ),
  shield: (
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" /><polyline points="9 12 11 14 15 10" />
    </svg>
  ),
  check: (
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10" /><path d="m9 12 2 2 4-4" />
    </svg>
  ),
  chart: (
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <line x1="18" y1="20" x2="18" y2="10" /><line x1="12" y1="20" x2="12" y2="4" /><line x1="6" y1="20" x2="6" y2="14" />
    </svg>
  ),
  phone: (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
    </svg>
  ),
  mail: (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <rect x="2" y="4" width="20" height="16" rx="2" /><polyline points="22,6 12,13 2,6" />
    </svg>
  ),
  pin: (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" /><circle cx="12" cy="10" r="3" />
    </svg>
  ),
  clock: (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10" /><polyline points="12 6 12 12 16 14" />
    </svg>
  ),
  arrow: (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <line x1="5" y1="12" x2="19" y2="12" /><polyline points="12 5 19 12 12 19" />
    </svg>
  ),
  star: (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" stroke="none">
      <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
    </svg>
  ),
}

/* ═══════════════════════════════════════════
   DATA
   ═══════════════════════════════════════════ */
const services = [
  { icon: I.tax, title: 'Tax Compliance & Returns', desc: 'Corporate and personal income tax, provisional tax, VAT returns, and strategic tax planning for full SARS compliance.' },
  { icon: I.book, title: 'Accounting & Bookkeeping', desc: 'Monthly bookkeeping, annual financial statements, management accounts, and general ledger maintenance.' },
  { icon: I.users, title: 'Payroll Management', desc: 'End-to-end payroll processing — IRP5s, EMP201 submissions, UIF, SDL, and COIDA handled with precision.' },
  { icon: I.shield, title: 'Company Secretarial', desc: 'CIPC registrations, annual returns, company amendments, share transfers, and statutory compliance.' },
  { icon: I.check, title: 'B-BBEE Compliance', desc: 'B-BBEE certificates, compliance consulting, scorecard analysis, and skills development planning.' },
  { icon: I.chart, title: 'Financial Advisory', desc: 'Strategic business planning, cash flow forecasting, growth advisory, and financial modelling.' },
]

const stats = [
  { value: 500, suffix: '+', label: 'Clients Served' },
  { value: 15, suffix: '+', label: 'Years Experience' },
  { value: 99, suffix: '%', label: 'SARS Compliance' },
  { value: 24, suffix: 'hr', label: 'Response Time' },
]

const steps = [
  { n: '01', title: 'Consultation', desc: 'We listen to your goals and understand your financial landscape.' },
  { n: '02', title: 'Assessment', desc: 'Thorough review of your financials and compliance status.' },
  { n: '03', title: 'Implementation', desc: 'Set up efficient systems, file returns, establish processes.' },
  { n: '04', title: 'Ongoing Support', desc: 'Continuous monthly management, reporting, and advisory.' },
]

const reviews = [
  { text: 'ATP transformed our financial operations. Their attention to detail and proactive tax planning has saved us significantly every year.', name: 'Sarah M.', role: 'Retail Group, Durban' },
  { text: 'Payroll is seamless — staff always paid on time, every SARS submission handled without us lifting a finger. Truly professional.', name: 'David K.', role: 'Manufacturing Co.' },
  { text: 'From company registration to BEE compliance, ATP handled everything. They genuinely care and it shows in every interaction.', name: 'Priya N.', role: 'Tech Startup, KZN' },
]

/* ═══════════════════════════════════════════
   NAVBAR
   ═══════════════════════════════════════════ */
function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 50)
    window.addEventListener('scroll', fn, { passive: true })
    return () => window.removeEventListener('scroll', fn)
  }, [])

  const links = [
    { h: '#home', l: 'Home' },
    { h: '#services', l: 'Services' },
    { h: '#about', l: 'About' },
    { h: '#process', l: 'Process' },
    { h: '#contact', l: 'Contact' },
  ]

  return (
    <>
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${scrolled ? 'nav-solid py-3' : 'nav-clear py-5'}`}>
        <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
          <a href="#home" className="flex items-center gap-3">
            <img src="/logo.jpg" alt="ATP" className="h-10 w-auto rounded" style={{ filter: 'brightness(1.1)' }} />
            <div className="hidden sm:block">
              <div className="text-lg font-bold text-white tracking-tight" style={{ fontFamily: 'Sora, sans-serif' }}>ATP</div>
              <div className="text-[0.6rem] text-teal-400 tracking-[0.15em] uppercase font-medium">Accounting &bull; Tax &bull; Payroll</div>
            </div>
          </a>

          <div className="hidden md:flex items-center gap-8">
            {links.map((l) => (
              <a key={l.h} href={l.h} className="text-sm text-slate-300 hover:text-teal-400 transition-colors font-medium">{l.l}</a>
            ))}
            <a href="#contact" className="btn-teal !py-2.5 !px-6 !text-sm">Get Started</a>
          </div>

          <button onClick={() => setOpen(!open)} className="md:hidden flex flex-col gap-1.5 p-2" aria-label="Menu">
            <span className={`w-6 h-0.5 bg-teal-400 transition-all ${open ? 'rotate-45 translate-y-2' : ''}`} />
            <span className={`w-6 h-0.5 bg-teal-400 transition-all ${open ? 'opacity-0' : ''}`} />
            <span className={`w-6 h-0.5 bg-teal-400 transition-all ${open ? '-rotate-45 -translate-y-2' : ''}`} />
          </button>
        </div>
      </nav>

      <div className={`mobile-menu ${open ? 'open' : ''}`}>
        {links.map((l) => (<a key={l.h} href={l.h} onClick={() => setOpen(false)}>{l.l}</a>))}
        <a href="#contact" className="btn-teal mt-4" onClick={() => setOpen(false)}>Get Started</a>
      </div>
    </>
  )
}

/* ═══════════════════════════════════════════
   HERO
   ═══════════════════════════════════════════ */
function Hero() {
  return (
    <section id="home" className="hero-section min-h-screen flex items-center relative">
      <div className="hero-particles" />
      <div className="hero-glow" style={{ top: '-10%', right: '-5%' }} />
      <div className="hero-glow" style={{ bottom: '-20%', left: '-10%', animationDelay: '3s' }} />

      <div className="max-w-7xl mx-auto px-6 py-32 md:py-0 relative z-10 w-full">
        <div className="text-center max-w-4xl mx-auto">
          <div className="teal-tag mx-auto mb-8" data-animate="up">
            <span className="w-2 h-2 bg-teal-400 rounded-full" />
            Trusted Financial Partner in South Africa
          </div>

          <h1
            className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-extrabold text-white leading-[1.08] mb-8 tracking-tight"
            style={{ fontFamily: 'Sora, sans-serif' }}
            data-animate="up" data-delay="1"
          >
            Smart Accounting
            <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-400 to-teal-300">
              Solutions
            </span>{' '}
            for Growing
            <br />
            Businesses
          </h1>

          <p className="text-lg md:text-xl text-slate-400 leading-relaxed mb-12 max-w-2xl mx-auto" data-animate="up" data-delay="2">
            SARS-registered practitioners delivering accounting, tax compliance,
            payroll management, and strategic financial advisory — so you can
            focus on what matters most.
          </p>

          <div className="flex flex-wrap justify-center gap-4" data-animate="up" data-delay="3">
            <a href="#contact" className="btn-teal">
              Schedule Free Consultation {I.arrow}
            </a>
            <a href="#services" className="btn-outline-teal">
              Explore Our Services
            </a>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2">
        <div className="w-6 h-10 border-2 border-slate-600 rounded-full flex items-start justify-center p-1.5">
          <div className="w-1.5 h-3 bg-teal-400 rounded-full animate-bounce" />
        </div>
      </div>
    </section>
  )
}

/* ═══════════════════════════════════════════
   SERVICES — White cards on dark bg
   ═══════════════════════════════════════════ */
function Services() {
  return (
    <section id="services" className="section-dark py-24 md:py-32">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="teal-tag mx-auto mb-6" data-animate="up">
            <span className="w-2 h-2 bg-teal-400 rounded-full" />
            Our Services
          </div>
          <h2
            className="text-3xl md:text-5xl font-extrabold text-white mb-5 tracking-tight"
            style={{ fontFamily: 'Sora, sans-serif' }}
            data-animate="up" data-delay="1"
          >
            Everything Your Business
            <br />
            <span className="text-teal-400">Needs to Thrive</span>
          </h2>
          <p className="text-lg text-slate-400 leading-relaxed" data-animate="up" data-delay="2">
            From tax compliance to strategic advisory, we provide end-to-end financial
            solutions tailored to your needs.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((s, i) => (
            <div key={s.title} className="card-white group" data-animate="up" data-delay={String(i + 1)}>
              <div className="w-14 h-14 rounded-2xl bg-teal-50 flex items-center justify-center text-teal-600 mb-6 group-hover:bg-teal-500 group-hover:text-white transition-all duration-300">
                {s.icon}
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3" style={{ fontFamily: 'Sora, sans-serif' }}>{s.title}</h3>
              <p className="text-gray-500 leading-relaxed text-[0.95rem]">{s.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ═══════════════════════════════════════════
   STATS BAND
   ═══════════════════════════════════════════ */
function Stats() {
  const s0 = useCountUp(stats[0].value, stats[0].suffix)
  const s1 = useCountUp(stats[1].value, stats[1].suffix)
  const s2 = useCountUp(stats[2].value, stats[2].suffix)
  const s3 = useCountUp(stats[3].value, stats[3].suffix)
  const refs = [s0, s1, s2, s3]

  return (
    <section className="section-darker py-20">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((s, i) => (
            <div key={s.label} ref={refs[i].ref} className="text-center" data-animate="up" data-delay={String(i + 1)}>
              <div className="stat-value text-teal-400 mb-2">{refs[i].val}</div>
              <div className="text-sm text-slate-400 font-medium tracking-wide uppercase">{s.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ═══════════════════════════════════════════
   ABOUT
   ═══════════════════════════════════════════ */
function About() {
  return (
    <section id="about" className="section-light py-24 md:py-32">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <div className="teal-tag-dark mb-6" data-animate="left">
              <span className="w-2 h-2 bg-teal-500 rounded-full" />
              About ATP
            </div>
            <h2
              className="text-3xl md:text-5xl font-extrabold text-gray-900 mb-6 tracking-tight leading-tight"
              style={{ fontFamily: 'Sora, sans-serif' }}
              data-animate="left" data-delay="1"
            >
              Your Trusted Partner in{' '}
              <span className="text-teal-600">Financial Excellence</span>
            </h2>
            <div className="space-y-4 text-gray-500 leading-relaxed text-lg" data-animate="left" data-delay="2">
              <p>
                Based in Durban, South Africa, Accounting Taxation and Payroll (Pty) Ltd
                has been the go-to financial partner for businesses of all sizes. Our team
                of SARS-registered tax practitioners combines deep expertise with a genuine
                commitment to your success.
              </p>
              <p>
                We don&apos;t just crunch numbers — we provide strategic insights that help
                you make better financial decisions, stay compliant, and grow with confidence.
              </p>
            </div>
            <div className="mt-8" data-animate="left" data-delay="3">
              <a href="#contact" className="btn-teal">
                Work With Us {I.arrow}
              </a>
            </div>
          </div>

          {/* Feature cards */}
          <div className="grid grid-cols-2 gap-4" data-animate="right" data-delay="2">
            {[
              { title: 'SARS Registered', desc: 'Fully registered tax practitioners with SARS compliance expertise.' },
              { title: 'Personalised Service', desc: 'Every client gets dedicated attention and tailored solutions.' },
              { title: 'Tech-Enabled', desc: 'Modern cloud-based tools for real-time financial visibility.' },
              { title: 'KZN Based', desc: 'Local presence in Durban with deep knowledge of SA regulations.' },
            ].map((f, i) => (
              <div key={f.title} className="bg-gray-50 rounded-2xl p-6 hover:bg-teal-50 transition-colors duration-300">
                <div className="w-10 h-10 rounded-xl bg-teal-100 text-teal-600 flex items-center justify-center mb-3">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12" /></svg>
                </div>
                <h4 className="font-bold text-gray-900 mb-1 text-sm" style={{ fontFamily: 'Sora, sans-serif' }}>{f.title}</h4>
                <p className="text-gray-500 text-xs leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

/* ═══════════════════════════════════════════
   PROCESS
   ═══════════════════════════════════════════ */
function Process() {
  return (
    <section id="process" className="section-dark py-24 md:py-32">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center max-w-2xl mx-auto mb-20">
          <div className="teal-tag mx-auto mb-6" data-animate="up">
            <span className="w-2 h-2 bg-teal-400 rounded-full" />
            How We Work
          </div>
          <h2
            className="text-3xl md:text-5xl font-extrabold text-white mb-5 tracking-tight"
            style={{ fontFamily: 'Sora, sans-serif' }}
            data-animate="up" data-delay="1"
          >
            Getting Started is <span className="text-teal-400">Simple</span>
          </h2>
          <p className="text-lg text-slate-400 leading-relaxed" data-animate="up" data-delay="2">
            Our refined process ensures a smooth transition and ongoing excellence.
          </p>
        </div>

        <div className="grid md:grid-cols-4 gap-8 relative">
          {steps.map((s, i) => (
            <div key={s.n} className="text-center relative" data-animate="up" data-delay={String(i + 1)}>
              {i < 3 && <div className="step-connector hidden md:block" />}
              <div className="step-circle bg-teal-500/10 border-2 border-teal-500/30 text-teal-400 mx-auto mb-6">
                {s.n}
              </div>
              <h3 className="text-xl font-bold text-white mb-3" style={{ fontFamily: 'Sora, sans-serif' }}>{s.title}</h3>
              <p className="text-slate-400 leading-relaxed text-sm max-w-[220px] mx-auto">{s.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ═══════════════════════════════════════════
   TESTIMONIALS
   ═══════════════════════════════════════════ */
function Testimonials() {
  return (
    <section className="section-darker py-24 md:py-32">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="teal-tag mx-auto mb-6" data-animate="up">
            <span className="w-2 h-2 bg-teal-400 rounded-full" />
            Client Reviews
          </div>
          <h2
            className="text-3xl md:text-5xl font-extrabold text-white mb-5 tracking-tight"
            style={{ fontFamily: 'Sora, sans-serif' }}
            data-animate="up" data-delay="1"
          >
            Trusted by Businesses <span className="text-teal-400">Across SA</span>
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {reviews.map((r, i) => (
            <div key={r.name} className="testimonial-card" data-animate="up" data-delay={String(i + 1)}>
              <div className="flex gap-1 text-teal-400 mb-4">
                {[...Array(5)].map((_, j) => <span key={j}>{I.star}</span>)}
              </div>
              <p className="text-slate-300 leading-relaxed mb-6 text-[0.95rem]">{r.text}</p>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-teal-500/20 flex items-center justify-center">
                  <span className="text-teal-400 font-bold text-sm" style={{ fontFamily: 'Sora' }}>{r.name[0]}</span>
                </div>
                <div>
                  <div className="text-sm text-white font-semibold">{r.name}</div>
                  <div className="text-xs text-slate-500">{r.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ═══════════════════════════════════════════
   CTA
   ═══════════════════════════════════════════ */
function CTA() {
  return (
    <section className="cta-teal py-20 md:py-24 relative">
      <div className="max-w-4xl mx-auto px-6 text-center relative z-10">
        <h2
          className="text-3xl md:text-4xl lg:text-5xl font-extrabold text-white mb-5 tracking-tight"
          style={{ fontFamily: 'Sora, sans-serif' }}
          data-animate="up"
        >
          Ready to Take Control of Your Finances?
        </h2>
        <p className="text-teal-100/80 text-lg mb-8 max-w-xl mx-auto" data-animate="up" data-delay="1">
          Let&apos;s discuss how ATP can streamline your accounting, ensure compliance,
          and help your business grow.
        </p>
        <div data-animate="up" data-delay="2">
          <a href="#contact" className="btn-dark">
            Get Started Today {I.arrow}
          </a>
        </div>
      </div>
    </section>
  )
}

/* ═══════════════════════════════════════════
   CONTACT
   ═══════════════════════════════════════════ */
function Contact() {
  const [sent, setSent] = useState(false)

  return (
    <section id="contact" className="section-dark py-24 md:py-32">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="teal-tag mx-auto mb-6" data-animate="up">
            <span className="w-2 h-2 bg-teal-400 rounded-full" />
            Contact Us
          </div>
          <h2
            className="text-3xl md:text-5xl font-extrabold text-white mb-5 tracking-tight"
            style={{ fontFamily: 'Sora, sans-serif' }}
            data-animate="up" data-delay="1"
          >
            Let&apos;s Start a <span className="text-teal-400">Conversation</span>
          </h2>
        </div>

        <div className="grid lg:grid-cols-5 gap-10">
          {/* Form */}
          <div className="lg:col-span-3" data-animate="up" data-delay="2">
            <form
              onSubmit={(e) => { e.preventDefault(); setSent(true); setTimeout(() => setSent(false), 4000) }}
              className="card-glass !p-8 space-y-5"
            >
              <div className="grid sm:grid-cols-2 gap-5">
                <input type="text" placeholder="Full Name" className="form-input-dark" required />
                <input type="email" placeholder="Email Address" className="form-input-dark" required />
              </div>
              <div className="grid sm:grid-cols-2 gap-5">
                <input type="tel" placeholder="Phone Number" className="form-input-dark" />
                <select className="form-input-dark" defaultValue="">
                  <option value="" disabled>Select Service</option>
                  <option>Tax Compliance</option>
                  <option>Accounting & Bookkeeping</option>
                  <option>Payroll Management</option>
                  <option>Company Secretarial</option>
                  <option>BEE Compliance</option>
                  <option>Financial Advisory</option>
                  <option>Other</option>
                </select>
              </div>
              <textarea rows={4} placeholder="Tell us about your needs..." className="form-input-dark resize-none" />
              <button type="submit" className="btn-teal w-full">
                {sent ? 'Thank you! We\'ll be in touch.' : 'Send Message'}
              </button>
            </form>
          </div>

          {/* Info */}
          <div className="lg:col-span-2 space-y-6" data-animate="up" data-delay="3">
            {[
              { icon: I.pin, label: 'Office', lines: ['29 Coedmore Road, Sea View', 'Durban, 4094', 'South Africa'] },
              { icon: I.phone, label: 'Telephone', lines: ['031 101 3876', '061 542 9391'] },
              { icon: I.mail, label: 'Email', lines: ['krish@atpservices.co.za'] },
              { icon: I.clock, label: 'Hours', lines: ['Mon–Fri: 08:00 – 17:00', 'Sat: 09:00 – 13:00', 'Sun: Closed'] },
            ].map((c) => (
              <div key={c.label} className="flex items-start gap-4">
                <div className="w-11 h-11 rounded-xl bg-teal-500/10 flex items-center justify-center text-teal-400 flex-shrink-0">
                  {c.icon}
                </div>
                <div>
                  <div className="text-sm text-white font-semibold mb-1">{c.label}</div>
                  {c.lines.map((l) => (
                    <div key={l} className="text-sm text-slate-400">{l}</div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

/* ═══════════════════════════════════════════
   FOOTER
   ═══════════════════════════════════════════ */
function Footer() {
  return (
    <footer className="footer-section pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-4 gap-10 mb-12">
          <div className="md:col-span-2">
            <div className="flex items-center gap-3 mb-4">
              <img src="/logo.jpg" alt="ATP" className="h-10 w-auto rounded" />
              <div>
                <div className="text-lg font-bold text-white tracking-tight" style={{ fontFamily: 'Sora' }}>ATP Services</div>
                <div className="text-[0.6rem] text-teal-400 tracking-[0.12em] uppercase font-medium">Accounting &bull; Taxation &bull; Payroll</div>
              </div>
            </div>
            <p className="text-sm text-slate-400 leading-relaxed max-w-sm">
              Trusted financial partner for businesses across South Africa.
              SARS-registered practitioners delivering precision and peace of mind.
            </p>
          </div>

          <div>
            <h4 className="font-bold text-white mb-4 text-sm" style={{ fontFamily: 'Sora' }}>Quick Links</h4>
            <div className="space-y-2.5">
              {['Home', 'Services', 'About', 'Process', 'Contact'].map((l) => (
                <a key={l} href={`#${l.toLowerCase()}`} className="block text-sm text-slate-400 hover:text-teal-400 transition-colors">{l}</a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-bold text-white mb-4 text-sm" style={{ fontFamily: 'Sora' }}>Services</h4>
            <div className="space-y-2.5">
              {['Tax Compliance', 'Accounting', 'Payroll', 'Company Secretarial', 'BEE Compliance', 'Advisory'].map((s) => (
                <a key={s} href="#services" className="block text-sm text-slate-400 hover:text-teal-400 transition-colors">{s}</a>
              ))}
            </div>
          </div>
        </div>

        <div className="border-t border-white/5 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-slate-500">&copy; {new Date().getFullYear()} Accounting Taxation and Payroll (Pty) Ltd. All rights reserved.</p>
          <p className="text-xs text-slate-600">Durban, South Africa</p>
        </div>
      </div>
    </footer>
  )
}

/* ═══════════════════════════════════════════
   MAIN
   ═══════════════════════════════════════════ */
export default function Home() {
  useScrollObserver()
  return (
    <main>
      <Navbar />
      <Hero />
      <Services />
      <Stats />
      <About />
      <Process />
      <Testimonials />
      <CTA />
      <Contact />
      <Footer />
    </main>
  )
}
