<?php
return [
    'name' => 'CustomerStatements',
    'description' => 'Customer Statement and Aging Module'
];
