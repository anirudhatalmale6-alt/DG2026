<?php

namespace Modules\CustomerStatements\Models;

use Illuminate\Database\Eloquent\Model;

class CustomerLedger extends Model
{
    protected $table = 'customer_ledger';

    protected $fillable = [
        'client_id',
        'date',
        'type',
        'reference',
        'description',
        'debit',
        'credit',
        'source_id',
        'source_type'
    ];
}
