<?php

namespace Modules\CustomerStatements\Http\Controllers;

use Illuminate\Routing\Controller;
use Modules\CustomerStatements\Services\LedgerService;
use Modules\CustomerStatements\Services\AgingService;

class StatementController extends Controller
{
    public function show($client_id)
    {
        $ledger = app(LedgerService::class)->getClientStatement($client_id);
        $aging = app(AgingService::class)->calculate($client_id);

        return view('customerstatements::statement',compact(
            'ledger',
            'aging'
        ));
    }
}
