<?php

use Illuminate\Support\Facades\Route;
use Modules\CustomerStatements\Http\Controllers\StatementController;

Route::middleware(['web','auth'])->group(function(){

    Route::get('/clients/{id}/statement',[StatementController::class,'show']);

});
