<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCustomerLedgerTable extends Migration
{
    public function up()
    {
        Schema::create('customer_ledger', function (Blueprint $table) {

            $table->id();
            $table->unsignedBigInteger('client_id');
            $table->date('date');
            $table->string('type');
            $table->string('reference');
            $table->string('description')->nullable();
            $table->decimal('debit',15,2)->default(0);
            $table->decimal('credit',15,2)->default(0);
            $table->unsignedBigInteger('source_id')->nullable();
            $table->string('source_type')->nullable();
            $table->timestamps();

        });
    }

    public function down()
    {
        Schema::dropIfExists('customer_ledger');
    }
}
