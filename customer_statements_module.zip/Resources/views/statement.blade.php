<h2>Customer Statement</h2>

<table border="1" cellpadding="6" cellspacing="0">
<thead>
<tr>
<th>Date</th>
<th>Reference</th>
<th>Description</th>
<th>Debit</th>
<th>Credit</th>
<th>Balance</th>
</tr>
</thead>

<tbody>

@foreach($ledger as $row)
<tr>
<td>{{ $row->date }}</td>
<td>{{ $row->reference }}</td>
<td>{{ $row->description }}</td>
<td>{{ number_format($row->debit,2) }}</td>
<td>{{ number_format($row->credit,2) }}</td>
<td>{{ number_format($row->balance,2) }}</td>
</tr>
@endforeach

</tbody>
</table>

<h3>Aging Summary</h3>

<table border="1" cellpadding="6" cellspacing="0">
<tr>
<th>Current</th>
<th>30 Days</th>
<th>60 Days</th>
<th>90+</th>
</tr>

<tr>
<td>{{ number_format($aging['current'],2) }}</td>
<td>{{ number_format($aging['30'],2) }}</td>
<td>{{ number_format($aging['60'],2) }}</td>
<td>{{ number_format($aging['90'],2) }}</td>
</tr>
</table>
