<?php

namespace Modules\CustomerStatements\Services;

use Modules\CustomerStatements\Models\CustomerLedger;

class LedgerService
{
    public function getClientStatement($client_id)
    {
        $transactions = CustomerLedger::where('client_id',$client_id)
            ->orderBy('date')
            ->orderBy('id')
            ->get();

        $balance = 0;

        foreach($transactions as $t){
            $balance += $t->debit;
            $balance -= $t->credit;
            $t->balance = $balance;
        }

        return $transactions;
    }
}
