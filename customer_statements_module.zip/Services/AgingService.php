<?php

namespace Modules\CustomerStatements\Services;

use Illuminate\Support\Facades\DB;

class AgingService
{
    public function calculate($client_id)
    {
        $invoices = DB::table('invoices')
            ->where('client_id',$client_id)
            ->where('balance','>',0)
            ->get();

        $aging = [
            'current'=>0,
            '30'=>0,
            '60'=>0,
            '90'=>0
        ];

        foreach($invoices as $invoice){

            $days = now()->diffInDays($invoice->due_date);

            if($days <= 30){
                $aging['current'] += $invoice->balance;
            }elseif($days <= 60){
                $aging['30'] += $invoice->balance;
            }elseif($days <= 90){
                $aging['60'] += $invoice->balance;
            }else{
                $aging['90'] += $invoice->balance;
            }
        }

        return $aging;
    }
}
