import type { Config } from 'tailwindcss'

const config: Config = {
  content: ['./app/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        navy: {
          950: '#050810',
          900: '#0a0f1c',
          800: '#0f1728',
          700: '#141f35',
          600: '#1b2a48',
          500: '#243658',
        },
        gold: {
          DEFAULT: '#c8a24e',
          light: '#dbb96a',
          lighter: '#ecd596',
          dark: '#a88535',
          glow: 'rgba(200, 162, 78, 0.12)',
        },
      },
      fontFamily: {
        serif: ['DM Serif Display', 'Georgia', 'serif'],
        sans: ['Outfit', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
}

export default config
