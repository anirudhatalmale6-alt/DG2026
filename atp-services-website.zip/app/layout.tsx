import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'ATP | Accounting Taxation & Payroll (Pty) Ltd — Durban, South Africa',
  description: 'Trusted accounting, tax compliance, payroll management, and financial advisory services in Durban, South Africa. SARS-registered practitioners delivering precision and peace of mind.',
  keywords: 'accounting, taxation, payroll, Durban, South Africa, SARS, tax returns, bookkeeping, BEE compliance, company secretarial, financial advisory, ATP',
  authors: [{ name: 'Accounting Taxation and Payroll (Pty) Ltd' }],
  openGraph: {
    title: 'ATP | Accounting Taxation & Payroll — Durban, South Africa',
    description: 'Trusted accounting, tax compliance, payroll management, and financial advisory services in Durban, South Africa.',
    url: 'https://atpservices.co.za',
    siteName: 'ATP Services',
    locale: 'en_ZA',
    type: 'website',
  },
  robots: { index: true, follow: true },
  alternates: { canonical: 'https://atpservices.co.za' },
}

const structuredData = {
  '@context': 'https://schema.org',
  '@type': 'AccountingService',
  name: 'Accounting Taxation and Payroll (Pty) Ltd',
  alternateName: 'ATP Services',
  url: 'https://atpservices.co.za',
  telephone: '+27311013876',
  email: 'krish@atpservices.co.za',
  address: {
    '@type': 'PostalAddress',
    streetAddress: '29 Coedmore Road, Sea View',
    addressLocality: 'Durban',
    postalCode: '4094',
    addressCountry: 'ZA',
  },
  areaServed: { '@type': 'Country', name: 'South Africa' },
  serviceType: [
    'Tax Compliance',
    'Accounting',
    'Bookkeeping',
    'Payroll Management',
    'Company Secretarial',
    'BEE Compliance',
    'Financial Advisory',
  ],
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=Outfit:wght@300;400;500;600;700&display=swap"
          rel="stylesheet"
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }}
        />
      </head>
      <body className="font-sans antialiased">{children}</body>
    </html>
  )
}
