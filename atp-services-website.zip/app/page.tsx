'use client'

import { useEffect, useState, useRef, useCallback } from 'react'

/* ═══════════════════════════════════════════
   Scroll Animation Observer
   ═══════════════════════════════════════════ */
function useScrollObserver() {
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible')
            observer.unobserve(entry.target)
          }
        })
      },
      { threshold: 0.12, rootMargin: '0px 0px -40px 0px' }
    )
    document.querySelectorAll('[data-animate]').forEach((el) => observer.observe(el))
    return () => observer.disconnect()
  }, [])
}

/* ═══════════════════════════════════════════
   Count-Up Hook
   ═══════════════════════════════════════════ */
function useCountUp(target: number, suffix: string, duration = 2000) {
  const [display, setDisplay] = useState('0' + suffix)
  const ref = useRef<HTMLDivElement>(null)
  const started = useRef(false)

  useEffect(() => {
    const el = ref.current
    if (!el) return

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !started.current) {
          started.current = true
          const startTime = performance.now()

          const animate = (now: number) => {
            const elapsed = now - startTime
            const progress = Math.min(elapsed / duration, 1)
            const eased = 1 - Math.pow(1 - progress, 3)
            const value = Math.round(eased * target)
            setDisplay(value + suffix)
            if (progress < 1) requestAnimationFrame(animate)
          }
          requestAnimationFrame(animate)
        }
      },
      { threshold: 0.5 }
    )
    observer.observe(el)
    return () => observer.disconnect()
  }, [target, suffix, duration])

  return { ref, display }
}

/* ═══════════════════════════════════════════
   SVG Icons
   ═══════════════════════════════════════════ */
const icons = {
  tax: (
    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z" />
      <polyline points="14 2 14 8 20 8" />
      <line x1="9" y1="15" x2="15" y2="15" />
      <line x1="9" y1="11" x2="15" y2="11" />
      <line x1="9" y1="19" x2="12" y2="19" />
    </svg>
  ),
  accounting: (
    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <rect x="2" y="3" width="20" height="18" rx="2" />
      <line x1="2" y1="9" x2="22" y2="9" />
      <line x1="12" y1="3" x2="12" y2="9" />
      <line x1="7" y1="13" x2="7" y2="13.01" />
      <line x1="12" y1="13" x2="12" y2="13.01" />
      <line x1="17" y1="13" x2="17" y2="13.01" />
      <line x1="7" y1="17" x2="7" y2="17.01" />
      <line x1="12" y1="17" x2="12" y2="17.01" />
      <line x1="17" y1="17" x2="17" y2="17.01" />
    </svg>
  ),
  payroll: (
    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path d="M23 21v-2a4 4 0 00-3-3.87" />
      <path d="M16 3.13a4 4 0 010 7.75" />
    </svg>
  ),
  secretarial: (
    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
      <polyline points="9 12 11 14 15 10" />
    </svg>
  ),
  bee: (
    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10" />
      <path d="M8 12l2 2 4-4" />
      <path d="M12 6v2" />
      <path d="M12 16v2" />
    </svg>
  ),
  advisory: (
    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <line x1="12" y1="20" x2="12" y2="10" />
      <line x1="18" y1="20" x2="18" y2="4" />
      <line x1="6" y1="20" x2="6" y2="16" />
      <circle cx="12" cy="7" r="3" />
    </svg>
  ),
  phone: (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6 19.79 19.79 0 01-3.07-8.67A2 2 0 014.11 2h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 16.92z" />
    </svg>
  ),
  mail: (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
      <polyline points="22,6 12,13 2,6" />
    </svg>
  ),
  mapPin: (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z" />
      <circle cx="12" cy="10" r="3" />
    </svg>
  ),
  clock: (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10" />
      <polyline points="12 6 12 12 16 14" />
    </svg>
  ),
  arrow: (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <line x1="5" y1="12" x2="19" y2="12" />
      <polyline points="12 5 19 12 12 19" />
    </svg>
  ),
  chevronDown: (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="6 9 12 15 18 9" />
    </svg>
  ),
}

/* ═══════════════════════════════════════════
   DATA
   ═══════════════════════════════════════════ */
const services = [
  {
    icon: icons.tax,
    title: 'Tax Compliance & Returns',
    desc: 'Corporate and personal income tax, provisional tax, VAT returns, and strategic tax planning to ensure full SARS compliance while minimising your tax burden.',
  },
  {
    icon: icons.accounting,
    title: 'Accounting & Bookkeeping',
    desc: 'Monthly bookkeeping, annual financial statements, management accounts, and general ledger maintenance with meticulous attention to every transaction.',
  },
  {
    icon: icons.payroll,
    title: 'Payroll Management',
    desc: 'End-to-end payroll processing including IRP5 certificates, EMP201 submissions, UIF, SDL, and COIDA — ensuring your employees are paid accurately and on time.',
  },
  {
    icon: icons.secretarial,
    title: 'Company Secretarial',
    desc: 'CIPC registrations, annual returns, company amendments, share transfers, and all statutory compliance requirements handled with professional precision.',
  },
  {
    icon: icons.bee,
    title: 'B-BBEE Compliance',
    desc: 'B-BBEE certificate applications, compliance consulting, scorecard analysis, and skills development planning to strengthen your transformation rating.',
  },
  {
    icon: icons.advisory,
    title: 'Financial Advisory',
    desc: 'Strategic business planning, cash flow forecasting, growth advisory, and financial modelling to help you make informed decisions and scale with confidence.',
  },
]

const stats = [
  { value: 500, suffix: '+', label: 'Clients Served' },
  { value: 15, suffix: '+', label: 'Years Experience' },
  { value: 99, suffix: '%', label: 'Compliance Rate' },
  { value: 24, suffix: 'hr', label: 'Response Time' },
]

const processSteps = [
  { num: '01', title: 'Consultation', desc: 'We listen to your needs and understand your business goals and financial landscape.' },
  { num: '02', title: 'Assessment', desc: 'A thorough review of your financials, compliance status, and areas for improvement.' },
  { num: '03', title: 'Implementation', desc: 'We set up efficient systems, file returns, and establish ongoing processes.' },
  { num: '04', title: 'Ongoing Support', desc: 'Continuous monthly management, reporting, and proactive advisory for growth.' },
]

const testimonials = [
  {
    quote: 'ATP transformed our financial operations. Their attention to detail and proactive approach to tax planning has saved us significantly year after year.',
    name: 'Sarah M.',
    company: 'Retail Group, Durban',
  },
  {
    quote: 'The payroll service is seamless. Our staff are always paid on time and every SARS submission is handled without us lifting a finger. Truly professional.',
    name: 'David K.',
    company: 'Manufacturing Co.',
  },
  {
    quote: 'From company registration to BEE compliance, ATP handled everything. They genuinely care about their clients and it shows in every interaction.',
    name: 'Priya N.',
    company: 'Tech Startup, KZN',
  },
]

/* ═══════════════════════════════════════════
   NAVBAR
   ═══════════════════════════════════════════ */
function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const links = [
    { href: '#home', label: 'Home' },
    { href: '#about', label: 'About' },
    { href: '#services', label: 'Services' },
    { href: '#process', label: 'Process' },
    { href: '#contact', label: 'Contact' },
  ]

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          scrolled ? 'nav-glass py-3' : 'nav-transparent py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
          {/* Logo */}
          <a href="#home" className="flex items-center gap-3">
            <img
              src="/logo.jpg"
              alt="ATP Services"
              className="h-10 w-auto rounded"
              style={{ filter: 'brightness(1.1)' }}
            />
            <div className="hidden sm:block">
              <div className="font-serif text-lg text-white leading-tight">ATP</div>
              <div className="text-[0.65rem] text-gold-light tracking-[0.15em] uppercase">
                Accounting &bull; Tax &bull; Payroll
              </div>
            </div>
          </a>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            {links.map((l) => (
              <a
                key={l.href}
                href={l.href}
                className="text-sm text-slate-300 hover:text-gold transition-colors duration-300 tracking-wide"
              >
                {l.label}
              </a>
            ))}
            <a href="#contact" className="btn-gold text-sm !py-2.5 !px-6">
              Free Consultation
            </a>
          </div>

          {/* Hamburger */}
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="md:hidden flex flex-col gap-1.5 p-2"
            aria-label="Menu"
          >
            <span
              className={`w-6 h-0.5 bg-gold transition-all duration-300 ${
                menuOpen ? 'rotate-45 translate-y-2' : ''
              }`}
            />
            <span
              className={`w-6 h-0.5 bg-gold transition-all duration-300 ${
                menuOpen ? 'opacity-0' : ''
              }`}
            />
            <span
              className={`w-6 h-0.5 bg-gold transition-all duration-300 ${
                menuOpen ? '-rotate-45 -translate-y-2' : ''
              }`}
            />
          </button>
        </div>
      </nav>

      {/* Mobile Menu */}
      <div className={`mobile-menu ${menuOpen ? 'open' : ''}`}>
        {links.map((l) => (
          <a key={l.href} href={l.href} onClick={() => setMenuOpen(false)}>
            {l.label}
          </a>
        ))}
        <a href="#contact" className="btn-gold mt-4" onClick={() => setMenuOpen(false)}>
          Free Consultation
        </a>
      </div>
    </>
  )
}

/* ═══════════════════════════════════════════
   HERO
   ═══════════════════════════════════════════ */
function Hero() {
  return (
    <section id="home" className="hero-bg min-h-screen flex items-center relative overflow-hidden">
      <div className="gold-arc hidden lg:block" />
      <div className="max-w-7xl mx-auto px-6 py-32 md:py-0 relative z-10">
        <div className="max-w-2xl">
          <div className="gold-tag mb-8" data-animate="up">
            <span className="w-1.5 h-1.5 bg-gold rounded-full" />
            Trusted Financial Partner
          </div>

          <h1
            className="font-serif text-4xl sm:text-5xl lg:text-6xl text-white leading-[1.15] mb-6"
            data-animate="up"
            data-delay="1"
          >
            Precision in Every Number,{' '}
            <span className="text-gold">Excellence</span> in Every Return
          </h1>

          <p
            className="text-lg text-slate-400 leading-relaxed mb-10 max-w-xl"
            data-animate="up"
            data-delay="2"
          >
            SARS-registered practitioners delivering accounting, tax compliance,
            payroll management, and strategic financial advisory to businesses
            across South Africa.
          </p>

          <div className="flex flex-wrap gap-4" data-animate="up" data-delay="3">
            <a href="#contact" className="btn-gold">
              Schedule Consultation {icons.arrow}
            </a>
            <a href="#services" className="btn-outline">
              Explore Services {icons.chevronDown}
            </a>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 opacity-40">
        <span className="text-xs text-slate-500 tracking-widest uppercase">Scroll</span>
        <div className="w-px h-8 bg-gradient-to-b from-gold to-transparent" />
      </div>
    </section>
  )
}

/* ═══════════════════════════════════════════
   SERVICES
   ═══════════════════════════════════════════ */
function Services() {
  return (
    <section id="services" className="section-dark section-pattern py-24 md:py-32 relative">
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="gold-tag mx-auto mb-6" data-animate="up">
            <span className="w-1.5 h-1.5 bg-gold rounded-full" />
            What We Do
          </div>
          <h2 className="font-serif text-3xl md:text-4xl text-white mb-4" data-animate="up" data-delay="1">
            Comprehensive Financial Services
          </h2>
          <p className="text-slate-400 leading-relaxed" data-animate="up" data-delay="2">
            From tax compliance to strategic advisory, we provide end-to-end financial
            solutions tailored to your business needs.
          </p>
        </div>

        {/* Cards Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((s, i) => (
            <div
              key={s.title}
              className="card-glass p-8"
              data-animate="up"
              data-delay={String(i + 1)}
            >
              <div className="w-14 h-14 rounded-xl bg-gold/10 flex items-center justify-center text-gold mb-5">
                {s.icon}
              </div>
              <h3 className="font-serif text-xl text-white mb-3">{s.title}</h3>
              <p className="text-sm text-slate-400 leading-relaxed">{s.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ═══════════════════════════════════════════
   ABOUT + STATS
   ═══════════════════════════════════════════ */
function About() {
  const s1 = useCountUp(stats[0].value, stats[0].suffix)
  const s2 = useCountUp(stats[1].value, stats[1].suffix)
  const s3 = useCountUp(stats[2].value, stats[2].suffix)
  const s4 = useCountUp(stats[3].value, stats[3].suffix)
  const statRefs = [s1, s2, s3, s4]

  return (
    <section id="about" className="section-gradient py-24 md:py-32">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left — Text */}
          <div>
            <div className="gold-tag mb-6" data-animate="left">
              <span className="w-1.5 h-1.5 bg-gold rounded-full" />
              About ATP
            </div>
            <h2
              className="font-serif text-3xl md:text-4xl text-white mb-6 leading-tight"
              data-animate="left"
              data-delay="1"
            >
              Your Trusted Partner in{' '}
              <span className="text-gold">Financial Excellence</span>
            </h2>
            <div className="gold-divider mb-6" data-animate="left" data-delay="2" />
            <div className="space-y-4 text-slate-400 leading-relaxed" data-animate="left" data-delay="3">
              <p>
                Based in Durban, South Africa, Accounting Taxation and Payroll (Pty) Ltd
                has been the go-to financial partner for businesses of all sizes. Our team
                of SARS-registered tax practitioners combines deep technical expertise with
                a genuine commitment to your success.
              </p>
              <p>
                We don&apos;t just crunch numbers — we provide strategic insights that help
                you make better financial decisions, stay compliant, and grow with confidence.
                Every client receives personalised attention because we believe your business
                deserves nothing less.
              </p>
            </div>
            <div className="mt-8" data-animate="left" data-delay="4">
              <a href="#contact" className="btn-gold">
                Work With Us {icons.arrow}
              </a>
            </div>
          </div>

          {/* Right — Stats Grid */}
          <div className="grid grid-cols-2 gap-5">
            {stats.map((s, i) => (
              <div
                key={s.label}
                ref={statRefs[i].ref}
                className="card-glass p-7 text-center"
                data-animate="scale"
                data-delay={String(i + 1)}
              >
                <div className="stat-number mb-2">{statRefs[i].display}</div>
                <div className="text-sm text-slate-400 font-medium">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

/* ═══════════════════════════════════════════
   PROCESS
   ═══════════════════════════════════════════ */
function Process() {
  return (
    <section id="process" className="section-dark py-24 md:py-32">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="gold-tag mx-auto mb-6" data-animate="up">
            <span className="w-1.5 h-1.5 bg-gold rounded-full" />
            How We Work
          </div>
          <h2 className="font-serif text-3xl md:text-4xl text-white mb-4" data-animate="up" data-delay="1">
            A Seamless Process, Built for You
          </h2>
          <p className="text-slate-400 leading-relaxed" data-animate="up" data-delay="2">
            Getting started is simple. We&apos;ve refined our process to ensure a smooth
            transition and ongoing excellence.
          </p>
        </div>

        {/* Steps */}
        <div className="relative">
          <div className="process-line hidden md:block" />
          <div className="grid md:grid-cols-4 gap-8">
            {processSteps.map((step, i) => (
              <div key={step.num} className="text-center relative" data-animate="up" data-delay={String(i + 1)}>
                <div className="w-14 h-14 rounded-full bg-navy-800 border-2 border-gold/30 flex items-center justify-center mx-auto mb-5 relative z-10">
                  <span className="font-serif text-gold text-lg">{step.num}</span>
                </div>
                <h3 className="font-serif text-xl text-white mb-3">{step.title}</h3>
                <p className="text-sm text-slate-400 leading-relaxed max-w-xs mx-auto">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

/* ═══════════════════════════════════════════
   TESTIMONIALS
   ═══════════════════════════════════════════ */
function Testimonials() {
  return (
    <section className="section-gradient py-24 md:py-32">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="gold-tag mx-auto mb-6" data-animate="up">
            <span className="w-1.5 h-1.5 bg-gold rounded-full" />
            Testimonials
          </div>
          <h2 className="font-serif text-3xl md:text-4xl text-white mb-4" data-animate="up" data-delay="1">
            What Our Clients Say
          </h2>
        </div>

        {/* Cards */}
        <div className="grid md:grid-cols-3 gap-6">
          {testimonials.map((t, i) => (
            <div
              key={t.name}
              className="card-glass p-8 relative"
              data-animate="up"
              data-delay={String(i + 1)}
            >
              <div className="quote-mark">&ldquo;</div>
              <p className="text-slate-300 leading-relaxed mb-6 relative z-10 pt-6">
                {t.quote}
              </p>
              <div className="flex items-center gap-3 relative z-10">
                <div className="w-10 h-10 rounded-full bg-gold/20 flex items-center justify-center">
                  <span className="font-serif text-gold text-sm">{t.name[0]}</span>
                </div>
                <div>
                  <div className="text-sm text-white font-medium">{t.name}</div>
                  <div className="text-xs text-slate-500">{t.company}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ═══════════════════════════════════════════
   CTA BANNER
   ═══════════════════════════════════════════ */
function CtaBanner() {
  return (
    <section className="cta-gradient py-20 md:py-24 relative overflow-hidden">
      <div className="max-w-4xl mx-auto px-6 text-center relative z-10">
        <h2
          className="font-serif text-3xl md:text-4xl text-navy-950 mb-4"
          data-animate="up"
        >
          Ready to Transform Your Financial Management?
        </h2>
        <p className="text-navy-800/80 mb-8 max-w-xl mx-auto" data-animate="up" data-delay="1">
          Let&apos;s discuss how ATP can streamline your accounting, ensure compliance,
          and help your business grow.
        </p>
        <div data-animate="up" data-delay="2">
          <a
            href="#contact"
            className="inline-flex items-center gap-2 px-8 py-4 bg-navy-950 text-gold font-semibold rounded-lg hover:bg-navy-900 transition-all duration-300 hover:-translate-y-0.5 shadow-xl"
          >
            Get Started Today {icons.arrow}
          </a>
        </div>
      </div>
    </section>
  )
}

/* ═══════════════════════════════════════════
   CONTACT
   ═══════════════════════════════════════════ */
function Contact() {
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = useCallback((e: React.FormEvent) => {
    e.preventDefault()
    setSubmitted(true)
    setTimeout(() => setSubmitted(false), 4000)
  }, [])

  return (
    <section id="contact" className="section-dark section-pattern py-24 md:py-32 relative">
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16">
          {/* Left — Form */}
          <div>
            <div className="gold-tag mb-6" data-animate="left">
              <span className="w-1.5 h-1.5 bg-gold rounded-full" />
              Get In Touch
            </div>
            <h2 className="font-serif text-3xl md:text-4xl text-white mb-4" data-animate="left" data-delay="1">
              Let&apos;s Start a Conversation
            </h2>
            <p className="text-slate-400 mb-8" data-animate="left" data-delay="2">
              Fill in the form below and we&apos;ll get back to you within 24 hours.
            </p>

            <form onSubmit={handleSubmit} className="space-y-5" data-animate="up" data-delay="3">
              <div className="grid sm:grid-cols-2 gap-5">
                <input type="text" placeholder="Full Name" className="form-input" required />
                <input type="email" placeholder="Email Address" className="form-input" required />
              </div>
              <div className="grid sm:grid-cols-2 gap-5">
                <input type="tel" placeholder="Phone Number" className="form-input" />
                <select className="form-input" defaultValue="">
                  <option value="" disabled>Select Service</option>
                  <option>Tax Compliance</option>
                  <option>Accounting & Bookkeeping</option>
                  <option>Payroll Management</option>
                  <option>Company Secretarial</option>
                  <option>BEE Compliance</option>
                  <option>Financial Advisory</option>
                  <option>Other</option>
                </select>
              </div>
              <textarea
                rows={4}
                placeholder="Tell us about your needs..."
                className="form-input resize-none"
              />
              <button
                type="submit"
                className="btn-gold w-full justify-center"
              >
                {submitted ? 'Thank you! We\'ll be in touch.' : 'Send Message'}
              </button>
            </form>
          </div>

          {/* Right — Info */}
          <div className="space-y-8" data-animate="right" data-delay="2">
            <div>
              <h3 className="font-serif text-xl text-white mb-6">Contact Information</h3>
              <div className="space-y-5">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-lg bg-gold/10 flex items-center justify-center text-gold flex-shrink-0 mt-0.5">
                    {icons.mapPin}
                  </div>
                  <div>
                    <div className="text-sm text-slate-300 font-medium mb-1">Office Address</div>
                    <div className="text-sm text-slate-400">
                      29 Coedmore Road, Sea View<br />
                      Durban, 4094<br />
                      South Africa
                    </div>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-lg bg-gold/10 flex items-center justify-center text-gold flex-shrink-0 mt-0.5">
                    {icons.phone}
                  </div>
                  <div>
                    <div className="text-sm text-slate-300 font-medium mb-1">Telephone</div>
                    <div className="text-sm text-slate-400">
                      <a href="tel:+27311013876" className="hover:text-gold transition-colors">031 101 3876</a><br />
                      <a href="tel:+27615429391" className="hover:text-gold transition-colors">061 542 9391</a>
                    </div>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-lg bg-gold/10 flex items-center justify-center text-gold flex-shrink-0 mt-0.5">
                    {icons.mail}
                  </div>
                  <div>
                    <div className="text-sm text-slate-300 font-medium mb-1">Email</div>
                    <div className="text-sm text-slate-400">
                      <a href="mailto:krish@atpservices.co.za" className="hover:text-gold transition-colors">
                        krish@atpservices.co.za
                      </a>
                    </div>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-lg bg-gold/10 flex items-center justify-center text-gold flex-shrink-0 mt-0.5">
                    {icons.clock}
                  </div>
                  <div>
                    <div className="text-sm text-slate-300 font-medium mb-1">Business Hours</div>
                    <div className="text-sm text-slate-400">
                      Monday – Friday: 08:00 – 17:00<br />
                      Saturday: 09:00 – 13:00<br />
                      Sunday: Closed
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Map placeholder with styled box */}
            <div className="card-glass p-1 overflow-hidden">
              <div className="w-full h-48 bg-navy-800 rounded-xl flex items-center justify-center">
                <div className="text-center">
                  <div className="text-gold mb-2">{icons.mapPin}</div>
                  <div className="text-sm text-slate-400">Sea View, Durban</div>
                  <a
                    href="https://maps.google.com/?q=29+Coedmore+Road+Sea+View+Durban+4094"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs text-gold hover:text-gold-light transition-colors mt-1 inline-block"
                  >
                    View on Google Maps &rarr;
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

/* ═══════════════════════════════════════════
   FOOTER
   ═══════════════════════════════════════════ */
function Footer() {
  return (
    <footer className="footer-gradient pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-4 gap-10 mb-12">
          {/* Brand */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-3 mb-4">
              <img src="/logo.jpg" alt="ATP" className="h-10 w-auto rounded" />
              <div>
                <div className="font-serif text-lg text-white">ATP Services</div>
                <div className="text-[0.65rem] text-gold-light tracking-[0.12em] uppercase">
                  Accounting &bull; Taxation &bull; Payroll
                </div>
              </div>
            </div>
            <p className="text-sm text-slate-400 leading-relaxed max-w-sm">
              Trusted financial partner for businesses across South Africa.
              SARS-registered practitioners delivering precision and peace of mind
              since day one.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-serif text-white mb-4">Quick Links</h4>
            <div className="space-y-2">
              {['Home', 'About', 'Services', 'Process', 'Contact'].map((l) => (
                <a
                  key={l}
                  href={`#${l.toLowerCase()}`}
                  className="block text-sm text-slate-400 hover:text-gold transition-colors"
                >
                  {l}
                </a>
              ))}
            </div>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-serif text-white mb-4">Services</h4>
            <div className="space-y-2">
              {[
                'Tax Compliance',
                'Accounting',
                'Payroll',
                'Company Secretarial',
                'BEE Compliance',
                'Financial Advisory',
              ].map((s) => (
                <a
                  key={s}
                  href="#services"
                  className="block text-sm text-slate-400 hover:text-gold transition-colors"
                >
                  {s}
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom */}
        <div className="border-t border-white/5 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-slate-500">
            &copy; {new Date().getFullYear()} Accounting Taxation and Payroll (Pty) Ltd. All rights reserved.
          </p>
          <p className="text-xs text-slate-600">
            Durban, South Africa
          </p>
        </div>
      </div>
    </footer>
  )
}

/* ═══════════════════════════════════════════
   MAIN PAGE
   ═══════════════════════════════════════════ */
export default function Home() {
  useScrollObserver()

  return (
    <main>
      <Navbar />
      <Hero />
      <Services />
      <About />
      <Process />
      <Testimonials />
      <CtaBanner />
      <Contact />
      <Footer />
    </main>
  )
}
